MAJOR = 0
MINOR = 1
PATCH = 0

__version__ = f"{MAJOR}.{MINOR}.{PATCH}"
